import { useState, useCallback } from "react";
import { calculateAge, formatNumber, getOrdinal } from "./utils/ageCalc";
import type { AgeResult } from "./utils/ageCalc";

// ─── SVG Icon Components ──────────────────────────────────────────
function CalendarIcon({ className = "w-5 h-5" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
    </svg>
  );
}

function ClockIcon({ className = "w-5 h-5" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  );
}

function CakeIcon({ className = "w-5 h-5" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 21v-8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8" />
      <path d="M4 16s.5-1 2-1 2.5 2 4 2 2.5-2 4-2 2.5 2 4 2 2-1 2-1" />
      <path d="M2 21h20" />
      <path d="M7 8v3" />
      <path d="M12 8v3" />
      <path d="M17 8v3" />
      <path d="M7 4h.01" />
      <path d="M12 4h.01" />
      <path d="M17 4h.01" />
    </svg>
  );
}

function SparkleIcon({ className = "w-5 h-5" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 3l1.912 5.813a2 2 0 0 0 1.275 1.275L21 12l-5.813 1.912a2 2 0 0 0-1.275 1.275L12 21l-1.912-5.813a2 2 0 0 0-1.275-1.275L3 12l5.813-1.912a2 2 0 0 0 1.275-1.275L12 3z" />
    </svg>
  );
}

function HeartIcon({ className = "w-5 h-5" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
    </svg>
  );
}

function MoonIcon({ className = "w-5 h-5" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
    </svg>
  );
}

function SunIcon({ className = "w-5 h-5" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="5" />
      <line x1="12" y1="1" x2="12" y2="3" />
      <line x1="12" y1="21" x2="12" y2="23" />
      <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
      <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
      <line x1="1" y1="12" x2="3" y2="12" />
      <line x1="21" y1="12" x2="23" y2="12" />
      <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
      <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
    </svg>
  );
}

function PartyIcon({ className = "w-5 h-5" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M5.8 11.3L2 22l10.7-3.8L22 22l-1.8-10.7L5.8 11.3z" />
      <path d="M1 2h2.3l.6 2.4 2.1 1.5-1.2 2.3 1.5 2.1L8 12l-2.9 1.2 1.5 2.1-1.2 2.3L7 19.1 11.6 19.7 12 22" />
    </svg>
  );
}

function ResetIcon({ className = "w-5 h-5" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <polyline points="1 4 1 10 7 10" />
      <path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10" />
    </svg>
  );
}

// ─── Stat Card Component ──────────────────────────────────────────
interface StatCardProps {
  label: string;
  value: string;
  icon: React.ReactNode;
  gradient: string;
  delay: number;
}

function StatCard({ label, value, icon, gradient, delay }: StatCardProps) {
  return (
    <div
      className={`result-card rounded-2xl p-5 bg-white/80 backdrop-blur border border-white/50 shadow-lg ${
        delay > 0 ? `animate-fade-in-up stagger-${Math.min(delay, 7)}` : ""
      }`}
    >
      <div className="flex items-center gap-3 mb-3">
        <div className={`p-2.5 rounded-xl ${gradient}`}>
          {icon}
        </div>
        <span className="text-sm font-medium text-slate-500 uppercase tracking-wider">{label}</span>
      </div>
      <div className="text-2xl md:text-3xl font-bold text-slate-800 animate-count-up">
        {value}
      </div>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────
export default function App() {
  const [dob, setDob] = useState("");
  const [result, setResult] = useState<AgeResult | null>(null);
  const [error, setError] = useState("");
  const [showResult, setShowResult] = useState(false);

  const getTodayMaxDate = () => {
    const today = new Date();
    return today.toISOString().split("T")[0];
  };

  const handleCalculate = useCallback(() => {
    if (!dob) {
      setError("Please select your date of birth");
      return;
    }

    const selectedDate = new Date(dob);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    selectedDate.setHours(0, 0, 0, 0);

    if (selectedDate > today) {
      setError("Date of birth cannot be in the future!");
      setShowResult(false);
      return;
    }

    if (selectedDate.getFullYear() < 1900) {
      setError("Please select a date after 1900");
      setShowResult(false);
      return;
    }

    const ageResult = calculateAge(selectedDate);
    if (ageResult.isFutureDate) {
      setError("Date of birth cannot be in the future!");
      setShowResult(false);
      return;
    }

    setResult(ageResult);
    setError("");
    setShowResult(true);
  }, [dob]);

  const handleReset = () => {
    setDob("");
    setResult(null);
    setShowResult(false);
    setError("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleCalculate();
    }
  };

  const getBirthdayMessage = (days: number) => {
    if (days === 0) return "🎉 Happy Birthday! Today is your special day!";
    if (days === 1) return "Your birthday is tomorrow! Get ready to celebrate! 🥳";
    if (days <= 7) return "Your birthday is this week! 🎈";
    if (days <= 30) return "Your birthday is less than a month away! 🎁";
    return `Counting down to your next birthday! 🎂`;
  };

  const formatDOB = (dateStr: string) => {
    if (!dateStr) return "";
    const d = new Date(dateStr + "T00:00:00");
    return d.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const getZodiacSign = (month: number, day: number) => {
    const signs = [
      { name: "Capricorn", symbol: "♑", emoji: "🐐", endDay: 19 },
      { name: "Aquarius", symbol: "♒", emoji: "💧", endDay: 20 },
      { name: "Pisces", symbol: "♓", emoji: "🐟", endDay: 20 },
      { name: "Aries", symbol: "♈", emoji: "🐏", endDay: 20 },
      { name: "Taurus", symbol: "♉", emoji: "🐂", endDay: 21 },
      { name: "Gemini", symbol: "♊", emoji: "👯", endDay: 21 },
      { name: "Cancer", symbol: "♋", emoji: "🦀", endDay: 22 },
      { name: "Leo", symbol: "♌", emoji: "🦁", endDay: 23 },
      { name: "Virgo", symbol: "♍", emoji: "🧚", endDay: 23 },
      { name: "Libra", symbol: "♎", emoji: "⚖️", endDay: 23 },
      { name: "Scorpio", symbol: "♏", emoji: "🦂", endDay: 22 },
      { name: "Sagittarius", symbol: "♐", emoji: "🏹", endDay: 21 },
    ];
    const idx = month - 1;
    if (day <= signs[idx].endDay) {
      return signs[idx];
    }
    return signs[(idx + 1) % 12];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 relative overflow-hidden">
      {/* Decorative Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] rounded-full bg-gradient-to-br from-purple-200/40 to-pink-200/40 blur-3xl" />
        <div className="absolute bottom-[-10%] left-[-5%] w-[600px] h-[600px] rounded-full bg-gradient-to-tr from-blue-200/40 to-indigo-200/40 blur-3xl" />
        <div className="absolute top-[40%] left-[30%] w-[300px] h-[300px] rounded-full bg-gradient-to-r from-pink-200/30 to-orange-200/30 blur-3xl" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 py-8 md:py-16">
        {/* Header */}
        <div className="text-center mb-10 md:mb-14 animate-fade-in-down">
          <div className="inline-flex items-center justify-center mb-4">
            <div className="w-16 h-16 md:w-20 md:h-20 rounded-2xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center shadow-xl shadow-purple-500/30 animate-float">
              <span className="text-3xl md:text-4xl">🎂</span>
            </div>
          </div>
          <h1 className="text-4xl md:text-6xl font-black gradient-text mb-3 leading-tight">
            Age Calculator
          </h1>
          <p className="text-lg md:text-xl text-slate-500 font-medium max-w-xl mx-auto">
            Discover your exact age in years, months, days, and more detailed stats
          </p>
        </div>

        {/* Input Card */}
        <div className="max-w-2xl mx-auto mb-10 animate-fade-in-up stagger-1">
          <div className="glass rounded-3xl p-6 md:p-8 shadow-xl shadow-indigo-500/10">
            <div className="flex flex-col gap-5">
              <div>
                <label htmlFor="dob" className="block text-sm font-semibold text-slate-600 mb-2 uppercase tracking-wider">
                  Date of Birth
                </label>
                <div className="relative">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                    <CalendarIcon />
                  </div>
                  <input
                    id="dob"
                    type="date"
                    value={dob}
                    max={getTodayMaxDate()}
                    onChange={(e) => {
                      setDob(e.target.value);
                      setError("");
                      if (showResult) setShowResult(false);
                    }}
                    onKeyDown={handleKeyDown}
                    className="w-full pl-12 pr-4 py-4 bg-white/80 border-2 border-slate-200 rounded-xl text-slate-800 text-lg font-medium focus:border-indigo-400 focus:ring-4 focus:ring-indigo-100 outline-none transition-all duration-200 hover:border-indigo-300 cursor-pointer"
                  />
                </div>
                {dob && (
                  <p className="mt-2 text-sm text-slate-500 pl-1">
                    You were born on{" "}
                    <span className="font-semibold text-indigo-600">
                      {formatDOB(dob)}
                    </span>
                  </p>
                )}
              </div>

              {error && (
                <div className="flex items-center gap-2 px-4 py-3 bg-red-50 border border-red-200 rounded-xl text-red-600 text-sm font-medium animate-scale-in">
                  <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                    <circle cx="12" cy="12" r="10" />
                    <line x1="15" y1="9" x2="9" y2="15" />
                    <line x1="9" y1="9" x2="15" y2="15" />
                  </svg>
                  {error}
                </div>
              )}

              <div className="flex gap-3">
                <button
                  onClick={handleCalculate}
                  className="btn-shine flex-1 py-4 px-6 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white font-bold text-lg rounded-xl shadow-lg shadow-indigo-500/30 hover:shadow-xl hover:shadow-indigo-500/40 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 flex items-center justify-center gap-2"
                >
                  <SparkleIcon className="w-5 h-5" />
                  Calculate My Age
                </button>
                {result && (
                  <button
                    onClick={handleReset}
                    className="py-4 px-5 bg-white/80 border-2 border-slate-200 text-slate-600 font-semibold rounded-xl hover:bg-red-50 hover:border-red-200 hover:text-red-600 transition-all duration-200 flex items-center gap-2"
                    title="Reset"
                  >
                    <ResetIcon className="w-5 h-5" />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Results Section */}
        {showResult && result && (
          <div className="max-w-4xl mx-auto space-y-8">
            {/* Main Age Display */}
            <div className="animate-fade-in-up stagger-2">
              <div className="glass rounded-3xl p-8 md:p-10 shadow-xl shadow-indigo-500/10">
                <div className="text-center mb-8">
                  <p className="text-sm font-semibold text-slate-400 uppercase tracking-widest mb-2">
                    Your Exact Age
                  </p>
                  <div className="flex items-center justify-center gap-4 md:gap-8 flex-wrap">
                    {[
                      { num: result.years, label: "Years" },
                      { num: result.months, label: "Months" },
                      { num: result.days, label: "Days" },
                    ].map((item) => (
                      <div key={item.label} className="text-center">
                        <div
                          className="text-5xl md:text-7xl font-black bg-gradient-to-b from-indigo-600 to-purple-700 bg-clip-text text-transparent leading-none"
                        >
                          {item.num}
                        </div>
                        <div className="text-sm md:text-base font-semibold text-slate-500 mt-1">
                          {item.label}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Fun facts row */}
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-sm text-slate-500">
                  <div className="flex items-center gap-2 px-4 py-2 bg-indigo-50 rounded-full">
                    <span className="text-lg">
                      {dob && (() => {
                        const d = new Date(dob + "T00:00:00");
                        const zodiac = getZodiacSign(d.getMonth() + 1, d.getDate());
                        return `${zodiac.emoji} ${zodiac.symbol} ${zodiac.name}`;
                      })()}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 px-4 py-2 bg-purple-50 rounded-full">
                    <HeartIcon className="w-4 h-4 text-pink-500" />
                    <span>
                      Born on {(() => {
                        const d = new Date(dob + "T00:00:00");
                        const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                        return days[d.getDay()];
                      })()}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 px-4 py-2 bg-pink-50 rounded-full">
                    <span className="text-lg">
                      🎂 Your {getOrdinal(result.years)} birthday
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Detailed Breakdown Grid */}
            <div className="animate-fade-in-up stagger-3">
              <div className="text-center mb-6">
                <h2 className="text-2xl font-bold text-slate-800">
                  📊 Detailed Breakdown
                </h2>
                <p className="text-slate-500 mt-1">How much time you've lived</p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <StatCard
                  label="Total Months"
                  value={formatNumber(result.totalMonths)}
                  icon={<MoonIcon className="w-5 h-5 text-white" />}
                  gradient="bg-gradient-to-br from-violet-400 to-purple-600"
                  delay={1}
                />
                <StatCard
                  label="Total Weeks"
                  value={formatNumber(result.totalWeeks)}
                  icon={<ClockIcon className="w-5 h-5 text-white" />}
                  gradient="bg-gradient-to-br from-blue-400 to-indigo-600"
                  delay={2}
                />
                <StatCard
                  label="Total Days"
                  value={formatNumber(result.totalDays)}
                  icon={<SunIcon className="w-5 h-5 text-white" />}
                  gradient="bg-gradient-to-br from-amber-400 to-orange-500"
                  delay={3}
                />
                <StatCard
                  label="Total Hours"
                  value={formatNumber(result.totalHours)}
                  icon={<ClockIcon className="w-5 h-5 text-white" />}
                  gradient="bg-gradient-to-br from-emerald-400 to-green-600"
                  delay={4}
                />
                <StatCard
                  label="Total Minutes"
                  value={formatNumber(result.totalMinutes)}
                  icon={<SparkleIcon className="w-5 h-5 text-white" />}
                  gradient="bg-gradient-to-br from-cyan-400 to-blue-600"
                  delay={5}
                />
                <StatCard
                  label="Total Seconds"
                  value={formatNumber(result.totalSeconds)}
                  icon={<PartyIcon className="w-5 h-5 text-white" />}
                  gradient="bg-gradient-to-br from-pink-400 to-rose-600"
                  delay={6}
                />
              </div>
            </div>

            {/* Next Birthday Countdown */}
            <div className="animate-fade-in-up stagger-4">
              <div className="glass rounded-3xl overflow-hidden shadow-xl shadow-purple-500/10">
                <div className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 p-6 md:p-8 text-white">
                  <div className="flex flex-col md:flex-row items-center gap-4 md:gap-6">
                    <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center flex-shrink-0">
                      <CakeIcon className="w-8 h-8" />
                    </div>
                    <div className="text-center md:text-left">
                      <h3 className="text-xl md:text-2xl font-bold mb-1">
                        Next Birthday Countdown
                      </h3>
                      <p className="text-white/80 font-medium">
                        {getBirthdayMessage(result.daysUntilBirthday)}
                      </p>
                    </div>
                  </div>

                  {result.daysUntilBirthday > 0 ? (
                    <div className="mt-6 grid grid-cols-4 gap-3 md:gap-4">
                      {[
                        { num: Math.floor(result.daysUntilBirthday / 30), label: "Months" },
                        { num: result.daysUntilBirthday % 30, label: "Days" },
                        { num: 24, label: "Hours" },
                        { num: 60, label: "Minutes" },
                      ].map((item) => (
                        <div
                          key={item.label}
                          className="bg-white/15 backdrop-blur rounded-2xl p-3 md:p-4 text-center"
                        >
                          <div className="text-3xl md:text-4xl font-black">
                            {item.num}
                          </div>
                          <div className="text-xs md:text-sm text-white/70 font-semibold mt-1 uppercase tracking-wider">
                            {item.label}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="mt-4 text-center py-4 bg-white/15 backdrop-blur rounded-2xl">
                      <span className="text-6xl animate-pulse-soft inline-block">🎉</span>
                      <p className="text-xl font-bold mt-2">
                        Happy Birthday! 🎂🎈
                      </p>
                      <p className="text-white/80 mt-1">
                        Today is your special day!
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="text-center mt-12 md:mt-16 animate-fade-in-up stagger-5">
          <p className="text-slate-400 text-sm font-medium">
            Built with 💜 — Calculate your age with precision
          </p>
        </div>
      </div>
    </div>
  );
}
